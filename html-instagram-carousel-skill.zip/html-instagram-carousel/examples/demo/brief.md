# Demo brief

- Topic: HTML carousel production
- Audience: creators and small teams
- Objective: explain the workflow
- Slide count: 3
- CTA: none
- Brand identifiers: none
- Photos: none
