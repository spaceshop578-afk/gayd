# Carousel brief

## Source
- Topic:
- Source material:
- Facts that must be preserved:
- Claims requiring evidence:

## Audience
- Who:
- Current awareness:
- Main problem:
- Desired outcome:

## Objective
- Primary objective:
- Slide count: 5
- Language:
- CTA:

## Brand inputs
- Brand name: optional
- Handle: optional
- Website: optional
- Logo path: optional
- Existing design tokens: optional

## Assets
- Portrait folder or attached portrait files:
- Background-image folder or attached background files:
- Logo folder or attached logo file:
- Visual-reference folder or attached references:
- May Claude use external stock/generated images: no by default
- Required attribution:

## Constraints
- Forbidden claims:
- Forbidden visual elements:
- Publication: disabled unless separately confirmed
