#!/usr/bin/env node
import { mkdirSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { spawnSync } from "node:child_process";

const projectArg = process.argv[2];
if (!projectArg) {
  console.error("Usage: node scripts/pipeline.mjs <project_dir>");
  process.exit(2);
}

const projectDir = resolve(projectArg);
const slidesDir = resolve(projectDir, "slides");
const outDir = resolve(projectDir, "out");
const qaDir = resolve(projectDir, "qa");
const reportPath = resolve(qaDir, "report.json");
const sheetPath = resolve(qaDir, "contact-sheet.png");
const scriptsDir = dirname(fileURLToPath(import.meta.url));

mkdirSync(outDir, { recursive: true });
mkdirSync(qaDir, { recursive: true });

const steps = [
  ["render.mjs", slidesDir, outDir],
  ["validate.mjs", slidesDir, outDir, reportPath],
  ["contact-sheet.mjs", outDir, sheetPath],
];

for (const [script, ...args] of steps) {
  const result = spawnSync(process.execPath, [resolve(scriptsDir, script), ...args], {
    stdio: "inherit",
  });
  if (result.error) {
    console.error(result.error.message);
    process.exit(1);
  }
  if (result.status !== 0) process.exit(result.status ?? 1);
}

console.log(JSON.stringify({
  status: "pass",
  project: projectDir,
  output: outDir,
  report: reportPath,
  contactSheet: sheetPath,
}));
