# HTML Instagram Carousel Skill

Portable Claude Code skill for creating Instagram carousels as HTML pages and exporting them to PNG with browser-based QA.

## Install

Copy this entire folder to:

```text
<your-project>/.claude/skills/html-instagram-carousel/
```

Then run:

```bash
cd <your-project>/.claude/skills/html-instagram-carousel
npm install
npx playwright install chromium
```

Start Claude Code in the project and ask:

```text
Use the html-instagram-carousel skill. Create a five-slide carousel from my source text. Prepare the brief and copy deck, generate HTML, render PNG files, validate them, and build a contact sheet. Do not publish anything.
```

## Test

```bash
npm test
```

Expected result: three demo slides render to exact 1080×1350 PNG files, validation passes, and a contact sheet is created.

For any carousel project, run the full export and QA pipeline from the project root with one command:

```bash
node .claude/skills/html-instagram-carousel/scripts/pipeline.mjs ./carousel-project
```

Brand identifiers and image libraries are project inputs and are not embedded in the skill.

## Supplying your images

Create these folders in the carousel project and place your own files there:

```text
carousel-project/assets/portraits/
carousel-project/assets/backgrounds/
carousel-project/assets/logos/
carousel-project/assets/references/
```

Alternatively, attach files in the Claude Code session and explicitly ask Claude to copy them into the matching folder. If no images are provided, the skill creates text-only slides instead of selecting external images without permission.
