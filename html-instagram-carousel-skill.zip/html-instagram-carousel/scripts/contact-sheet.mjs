#!/usr/bin/env node
import { readdirSync, existsSync, mkdirSync, writeFileSync, rmSync } from "node:fs";
import { resolve, join, dirname } from "node:path";
import { pathToFileURL } from "node:url";
import { chromium } from "playwright";

const [outArg, sheetArg] = process.argv.slice(2);
if (!outArg || !sheetArg) {
  console.error("Usage: node scripts/contact-sheet.mjs <png_dir> <contact-sheet.png>");
  process.exit(1);
}
const outDir = resolve(outArg);
const sheetPath = resolve(sheetArg);
if (!existsSync(outDir)) {
  console.error(`ERR PNG directory not found: ${outDir}`);
  process.exit(1);
}
const files = readdirSync(outDir).filter(f => /^slide_\d+\.png$/.test(f)).sort();
if (!files.length) {
  console.error(`ERR no slide_NN.png files in ${outDir}`);
  process.exit(1);
}
mkdirSync(dirname(sheetPath), { recursive: true });
const tempPath = join(dirname(sheetPath), ".contact-sheet.html");
const cards = files.map((file, index) => `<figure><img src="${pathToFileURL(join(outDir, file)).href}"><figcaption>${String(index + 1).padStart(2, "0")}</figcaption></figure>`).join("\n");
writeFileSync(tempPath, `<!doctype html><html><head><meta charset="UTF-8"><style>*{box-sizing:border-box}body{margin:0;padding:48px;background:#e9edf1;font-family:Arial,sans-serif}.grid{display:grid;grid-template-columns:repeat(3,360px);gap:32px;align-items:start}figure{margin:0;background:white;padding:12px;border-radius:12px;box-shadow:0 8px 24px #0002}img{display:block;width:336px;height:420px;object-fit:cover}figcaption{padding:10px 2px 2px;font-weight:700;color:#17212b}</style></head><body><main class="grid">${cards}</main></body></html>`);
const browser = await chromium.launch({ headless: true });
try {
  const rows = Math.ceil(files.length / 3);
  const page = await browser.newPage({ viewport: { width: 1232, height: Math.max(620, 96 + rows * 486) }, deviceScaleFactor: 1 });
  await page.goto(pathToFileURL(tempPath).href, { waitUntil: "networkidle" });
  await page.screenshot({ path: sheetPath, fullPage: true });
  console.log(`created ${sheetPath}`);
} finally {
  await browser.close();
  rmSync(tempPath, { force: true });
}
