#!/usr/bin/env node
import { readdirSync, existsSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { resolve, join, dirname } from "node:path";
import { pathToFileURL } from "node:url";
import { chromium } from "playwright";

const [slidesArg, outArg, reportArg] = process.argv.slice(2);
if (!slidesArg || !outArg || !reportArg) {
  console.error("Usage: node scripts/validate.mjs <slides_dir> <out_dir> <report.json>");
  process.exit(1);
}
const slidesDir = resolve(slidesArg);
const outDir = resolve(outArg);
const reportPath = resolve(reportArg);
if (!existsSync(slidesDir)) {
  console.error(`ERR slides directory not found: ${slidesDir}`);
  process.exit(1);
}
const htmlFiles = readdirSync(slidesDir).filter(f => /^slide_\d+\.html$/.test(f)).sort();
const pngFiles = existsSync(outDir) ? readdirSync(outDir).filter(f => /^slide_\d+\.png$/.test(f)).sort() : [];
const expectedNames = htmlFiles.map((_, i) => `slide_${String(i + 1).padStart(2, "0")}.html`);
const namingPass = JSON.stringify(htmlFiles) === JSON.stringify(expectedNames);

function pngDimensions(path) {
  const data = readFileSync(path);
  if (data.length < 24 || data.toString("ascii", 1, 4) !== "PNG") return null;
  return { width: data.readUInt32BE(16), height: data.readUInt32BE(20) };
}

const browser = await chromium.launch({ headless: true });
const results = [];
try {
  const context = await browser.newContext({ viewport: { width: 1080, height: 1350 }, deviceScaleFactor: 1 });
  const page = await context.newPage();
  for (const file of htmlFiles) {
    const consoleErrors = [];
    const onConsole = msg => { if (msg.type() === "error") consoleErrors.push(msg.text()); };
    const onPageError = err => consoleErrors.push(err.message);
    page.on("console", onConsole);
    page.on("pageerror", onPageError);
    await page.goto(pathToFileURL(join(slidesDir, file)).href, { waitUntil: "networkidle" });
    const checks = await page.evaluate(async () => {
      await document.fonts.ready;
      const root = document.querySelector(".slide");
      const canvas = root ? root.getBoundingClientRect() : null;
      const marked = [...document.querySelectorAll("[data-qa]")].map((el, index) => {
        const r = el.getBoundingClientRect();
        const kind = el.getAttribute("data-qa");
        const style = getComputedStyle(el);
        const clipsContent = ["hidden", "clip", "auto", "scroll"].includes(style.overflowY) || ["hidden", "clip", "auto", "scroll"].includes(style.overflowX);
        return {
          index, kind, tag: el.tagName,
          text: (el.textContent || "").trim().slice(0, 80),
          clipped: kind === "text" && clipsContent && (el.scrollHeight > el.clientHeight + 1 || el.scrollWidth > el.clientWidth + 1),
          outside: r.left < -1 || r.top < -1 || r.right > 1081 || r.bottom > 1351
        };
      });
      const images = [...document.images].map(img => ({ src: img.getAttribute("src"), loaded: img.complete && img.naturalWidth > 0 }));
      return {
        rootPresent: Boolean(root),
        canvas: canvas ? { width: canvas.width, height: canvas.height } : null,
        documentSize: { width: document.documentElement.scrollWidth, height: document.documentElement.scrollHeight },
        fontsReady: document.fonts.status === "loaded",
        marked, images
      };
    });
    page.off("console", onConsole);
    page.off("pageerror", onPageError);
    const pngName = file.replace(/\.html$/, ".png");
    const pngPath = join(outDir, pngName);
    const dims = existsSync(pngPath) ? pngDimensions(pngPath) : null;
    const failures = [];
    if (!checks.rootPresent) failures.push("missing .slide root");
    if (!checks.canvas || checks.canvas.width !== 1080 || checks.canvas.height !== 1350) failures.push("canvas is not 1080x1350");
    if (checks.documentSize.width !== 1080 || checks.documentSize.height !== 1350) failures.push("document overflow");
    if (!checks.fontsReady) failures.push("fonts not ready");
    if (checks.marked.some(x => x.clipped)) failures.push("marked text clipped");
    if (checks.marked.some(x => x.outside)) failures.push("marked element outside canvas");
    if (checks.images.some(x => !x.loaded)) failures.push("image failed to load");
    if (consoleErrors.length) failures.push("browser console error");
    if (!dims) failures.push("PNG missing or invalid");
    else if (dims.width !== 1080 || dims.height !== 1350) failures.push("PNG is not 1080x1350");
    results.push({ file, png: pngName, dimensions: dims, checks, consoleErrors, failures, status: failures.length ? "fail" : "pass" });
  }
} finally {
  await browser.close();
}
const report = {
  status: namingPass && htmlFiles.length > 0 && pngFiles.length === htmlFiles.length && results.every(x => x.status === "pass") ? "pass" : "fail",
  htmlCount: htmlFiles.length,
  pngCount: pngFiles.length,
  sequentialNaming: namingPass,
  slides: results
};
mkdirSync(dirname(reportPath), { recursive: true });
writeFileSync(reportPath, JSON.stringify(report, null, 2) + "\n");
console.log(JSON.stringify({ status: report.status, htmlCount: report.htmlCount, pngCount: report.pngCount, failedSlides: results.filter(x => x.status === "fail").length }));
process.exit(report.status === "pass" ? 0 : 1);
