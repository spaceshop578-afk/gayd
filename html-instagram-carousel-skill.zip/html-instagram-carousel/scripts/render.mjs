#!/usr/bin/env node
import { readdirSync, mkdirSync, existsSync } from "node:fs";
import { resolve, join, basename } from "node:path";
import { pathToFileURL } from "node:url";
import { chromium } from "playwright";

const [slidesArg, outArg] = process.argv.slice(2);
if (!slidesArg || !outArg) {
  console.error("Usage: node scripts/render.mjs <slides_dir> <out_dir>");
  process.exit(1);
}
const slidesDir = resolve(slidesArg);
const outDir = resolve(outArg);
if (!existsSync(slidesDir)) {
  console.error(`ERR slides directory not found: ${slidesDir}`);
  process.exit(1);
}
const slides = readdirSync(slidesDir).filter(f => /^slide_\d+\.html$/.test(f)).sort();
if (!slides.length) {
  console.error(`ERR no slide_NN.html files in ${slidesDir}`);
  process.exit(1);
}
mkdirSync(outDir, { recursive: true });
const browser = await chromium.launch({ headless: true });
try {
  const context = await browser.newContext({ viewport: { width: 1080, height: 1350 }, deviceScaleFactor: 1 });
  const page = await context.newPage();
  for (const file of slides) {
    const url = pathToFileURL(join(slidesDir, file)).href;
    await page.goto(url, { waitUntil: "networkidle" });
    await page.evaluate(async () => {
      await document.fonts.ready;
      await Promise.all([...document.images].map(img => img.complete ? Promise.resolve() : new Promise(done => {
        img.addEventListener("load", done, { once: true });
        img.addEventListener("error", done, { once: true });
      })));
    });
    await page.waitForTimeout(150);
    const output = join(outDir, `${basename(file, ".html")}.png`);
    await page.screenshot({ path: output, fullPage: false });
    console.log(`rendered ${output}`);
  }
} finally {
  await browser.close();
}
